﻿/*
 * Sims2Tools - a toolkit for manipulating The Sims 2 DBPF files
 *
 * William Howard - 2020-2026
 *
 * Parts of this code derived from the SimPE project - https://sourceforge.net/projects/simpe/
 * Parts of this code derived from the SimUnity2 project - https://github.com/LazyDuchess/SimUnity2 
 * Parts of this code may have been decompiled with the JetBrains decompiler
 *
 * Permission granted to use this code in any way, except to claim it as your own or sell it
 */

using Sims2Tools.DBPF.Utils;
using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.Serialization;

namespace Sims2Tools.DBPF
{
    public interface IDBPFKey
    {
        TypeTypeID TypeID { get; }
        TypeGroupID GroupID { get; }
        TypeResourceID ResourceID { get; }
        TypeInstanceID InstanceID { get; }

        int TGIHash { get; }
        int TGIRHash { get; }
    }

    [Serializable]
    public class DBPFKey : IDBPFKey, ISerializable, IEquatable<DBPFKey>, IComparable<DBPFKey>
    {
        private TypeTypeID typeID;
        private TypeGroupID groupID;
        private TypeResourceID resourceID;
        private TypeInstanceID instanceID;

        private int tgiHash = 0;
        private int tgirHash = 0;

        private string tgriString = null;

        public TypeTypeID TypeID => typeID;

        public TypeGroupID GroupID => groupID;

        public TypeResourceID ResourceID => resourceID;

        public TypeInstanceID InstanceID => instanceID;

        public bool IsTGIRValid(string sgName)
        {
            string name = Hashes.StripHashFromName(sgName);
            Debug.Assert(!string.IsNullOrEmpty(name), "SG Name cannot be blank!");

            return (Hashes.InstanceIDHash(name) == InstanceID && Hashes.ResourceIDHash(name) == ResourceID);
        }

        public void FixTGIR(string sgName)
        {
            if (!IsTGIRValid(sgName))
            {
                string name = Hashes.StripHashFromName(sgName);

                instanceID = Hashes.InstanceIDHash(name);
                resourceID = Hashes.ResourceIDHash(name);
            }
        }

        public void ChangeIR(TypeInstanceID instanceID, TypeResourceID resourceID)
        {
            this.instanceID = instanceID;
            this.resourceID = resourceID;
        }

        public int TGIHash
        {
            get
            {
                if (tgiHash == 0)
                    tgiHash = Hashes.TGIHash(InstanceID, TypeID, GroupID);

                return tgiHash;
            }
        }

        public int TGIRHash
        {
            get
            {
                if (tgirHash == 0)
                    tgirHash = Hashes.TGIRHash(InstanceID, ResourceID, TypeID, GroupID);

                return tgirHash;
            }
        }

        public string TGRIString
        {
            get
            {
                if (tgriString == null)
                    tgriString = $"{DBPFData.TypeName(TypeID)}-{GroupID}-{ResourceID}-{InstanceID}";

                return tgriString;
            }
        }

        public DBPFKey(TypeTypeID typeID, TypeGroupID groupID, TypeInstanceID instanceID, TypeResourceID resourceID)
        {
            this.typeID = typeID;
            this.groupID = groupID;
            this.resourceID = resourceID;
            this.instanceID = instanceID;
        }

        public DBPFKey(IDBPFKey key) : this(key.TypeID, key.GroupID, key.InstanceID, key.ResourceID)
        {
        }

        public DBPFKey(TypeTypeID typeId, IDBPFKey key) : this(typeId, key.GroupID, key.InstanceID, key.ResourceID)
        {
        }

        public DBPFKey(string tgriString)
        {
            string[] tgri = tgriString.Split(new char[] { '-' });

            this.typeID = DBPFData.TypeID(tgri[0]);
            this.groupID = (TypeGroupID)UInt32.Parse(tgri[1].Substring(2), NumberStyles.HexNumber);
            this.resourceID = (TypeResourceID)UInt32.Parse(tgri[2].Substring(2), NumberStyles.HexNumber);
            this.instanceID = (TypeInstanceID)UInt32.Parse(tgri[3].Substring(2), NumberStyles.HexNumber);
        }

        protected void ChangeTypeID(TypeTypeID typeID)
        {
            this.typeID = typeID;
        }

        protected void ChangeGroupID(TypeGroupID groupID)
        {
            this.groupID = groupID;
        }

        public bool Equals(DBPFKey other)
        {
            if (other == null) return false;

            return (this.TypeID == other.TypeID &&
                    this.GroupID == other.GroupID &&
                    this.ResourceID == other.ResourceID &&
                    this.InstanceID == other.InstanceID);
        }

        public override bool Equals(object other) => (other is DBPFKey key) && Equals(key);

        public override int GetHashCode() => TGIRHash;

        public int CompareTo(DBPFKey other) => this.TGRIString.CompareTo(other.TGRIString);

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("typeID", typeID.AsUInt());
            info.AddValue("groupID", groupID.AsUInt());
            info.AddValue("resourceID", resourceID.AsUInt());
            info.AddValue("instanceID", instanceID.AsUInt());
        }

        protected DBPFKey(SerializationInfo info, StreamingContext context)
        {
            typeID = (TypeTypeID)info.GetUInt32("typeID");
            groupID = (TypeGroupID)info.GetUInt32("groupID");
            resourceID = (TypeResourceID)info.GetUInt32("resourceID");
            instanceID = (TypeInstanceID)info.GetUInt32("instanceID");

            tgiHash = 0;
            tgirHash = 0;

            tgriString = null;
        }

        public override string ToString() => $"{DBPFData.TypeName(TypeID)}-{GroupID}-{ResourceID}-{InstanceID}";
    }

    public class DBPFScriptableKey : DBPFKey, IDbpfScriptable
    {
        public DBPFScriptableKey(TypeTypeID typeID, TypeGroupID groupID, TypeInstanceID instanceID, TypeResourceID resourceID) : base(typeID, groupID, instanceID, resourceID)
        {
        }

        public DBPFScriptableKey(DBPFKey key) : this(key.TypeID, key.GroupID, key.InstanceID, key.ResourceID)
        {
        }

        #region IDBPFScriptable
        public bool Assert(string item, ScriptValue sv)
        {
            if (item.Equals("type"))
            {
                return DBPFData.TypeName(TypeID).Equals(sv.ToUpper());
            }
            else if (item.Equals("group"))
            {
                return GroupID.Hex8String().Equals(sv.ToUpper());
            }
            else if (item.Equals("instance"))
            {
                return InstanceID.Hex8String().Equals(sv.ToUpper());
            }
            else if (item.Equals("resource"))
            {
                return ResourceID.Hex8String().Equals(sv.ToUpper());
            }

            throw new NotImplementedException();
        }

        public bool Assignment(string item, ScriptValue sv)
        {
            if (item.Equals("type"))
            {
                ChangeTypeID(sv);
                return true;
            }
            else if (item.Equals("group"))
            {
                ChangeGroupID(sv);
                return true;
            }
            else if (item.Equals("instance"))
            {
                ChangeIR(sv, ResourceID);
                return true;
            }
            else if (item.Equals("resource"))
            {
                ChangeIR(InstanceID, sv);
                return true;
            }

            return false;
        }

        public ScriptValue Value(string item)
        {
            if (item.Equals("type"))
            {
                return new ScriptValue(TypeID.ToString());
            }
            else if (item.Equals("group"))
            {
                return new ScriptValue(GroupID.ToString());
            }
            else if (item.Equals("instance"))
            {
                return new ScriptValue(InstanceID.ToString());
            }
            else if (item.Equals("resource"))
            {
                return new ScriptValue(ResourceID.ToString());
            }

            return null;
        }

        public IDbpfScriptable Indexed(int index, bool clone)
        {
            throw new NotImplementedException();
        }
        #endregion
    }

    public interface IDBPFNamedKey : IDBPFKey
    {
        string KeyName
        {
            get;
        }
    }

    public abstract class DBPFNamedKey : DBPFKey, IDBPFNamedKey
    {
        protected string _keyName;

        public virtual string KeyName => _keyName;

        public DBPFNamedKey(TypeTypeID typeID, TypeGroupID groupID, TypeInstanceID instanceID, TypeResourceID resourceID, string keyName) : base(typeID, groupID, instanceID, resourceID)
        {
            this._keyName = keyName;
        }

        public DBPFNamedKey(IDBPFKey key, string keyName) : this(key.TypeID, key.GroupID, key.InstanceID, key.ResourceID, keyName)
        {
        }

        public DBPFNamedKey(IDBPFNamedKey namedKey) : this(namedKey, namedKey.KeyName)
        {
        }

        public override string ToString()
        {
            return $"{base.ToString()} '{KeyName}'";
        }
    }
}
